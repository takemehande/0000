package sun.net.www;

public class ParseUtil {
    public static String encodePath(String path, boolean flag) {
        throw new RuntimeException("Stub!");
    }
}
