package com.android.internal.os;

import android.os.IBinder;

public class BinderInternal {
    public static final native IBinder getContextObject();
}
