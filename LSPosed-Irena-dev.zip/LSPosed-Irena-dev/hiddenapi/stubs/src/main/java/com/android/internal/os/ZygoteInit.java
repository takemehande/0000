package com.android.internal.os;

public class ZygoteInit {
}
