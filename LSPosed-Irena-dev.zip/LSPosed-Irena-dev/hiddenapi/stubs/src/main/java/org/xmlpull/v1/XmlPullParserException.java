package org.xmlpull.v1;

public class XmlPullParserException extends Throwable {
}
