package android.ddm;

public class DdmHandleAppName {
    public static void setAppName(String name, int userId) {
        throw new RuntimeException("STUB");
    }
}
