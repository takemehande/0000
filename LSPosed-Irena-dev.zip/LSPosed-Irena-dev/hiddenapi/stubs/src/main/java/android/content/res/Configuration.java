package android.content.res;

public class Configuration {
}
