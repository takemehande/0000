package android.permission;

import java.util.List;

public interface IPermissionManager {

    List<?> getSplitPermissions();
}
