package android.content;

public class IntentFilter {

}
