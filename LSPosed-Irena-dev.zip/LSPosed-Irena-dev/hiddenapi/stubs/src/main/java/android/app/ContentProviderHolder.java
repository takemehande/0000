package android.app;

import android.content.IContentProvider;

public class ContentProviderHolder {
    public IContentProvider provider;
}
