package android.app;

import android.content.Context;

public class ContextImpl extends Context {
}
