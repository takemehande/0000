package android.util;

public class TypedValue {
}
