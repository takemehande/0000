package android.content;

public class IntentSender {
}
