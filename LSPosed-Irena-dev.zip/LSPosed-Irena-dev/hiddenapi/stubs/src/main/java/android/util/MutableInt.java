package android.util;

public final class MutableInt {
    public int value;

    public MutableInt(int value) {
        this.value = value;
    }
}
